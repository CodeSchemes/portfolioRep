
#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
using namespace std;

int main()
{
    int intTotal;
    char choice;
    double deposit;
    double withdraw;
    string total;
    double prevTotal = 0;
    double depositAmount = 0;
    double withdrawAmount = 0;

    ofstream fileOut("checkingInfo.txt", ios_base::app);
    ifstream fileIn("checkingInfo.txt", ios_base::app);

    fileIn.ignore(100, '\n');
    getline(fileIn, total, '\n');
    fileOut << "Checking Balance:       ";

    cout << "Please type in D, W, or B (or E to exit)" << endl
        << "D - Deposit" << endl
        << "W - Withdraw" << endl
        << "B - Balance" << endl;
    std::cin >> choice;
 
    while (choice != 'E') {
        
        int intTotal = stod("total");
        prevTotal = intTotal;

        if (choice == 'D') {
            cout << "Enter Amount to Deposit: ";
            std::cin >> deposit;
            intTotal = prevTotal + deposit;
            depositAmount = deposit;
            cout << "Account Balance: " << prevTotal << endl
                << "Deposit Amount: " << depositAmount <<  endl
                << "Current Balance: " << intTotal <<  endl <<  endl;
        }
        else if (choice == 'W') {
            cout << "Enter Amount to Withdraw: ";
            std::cin >> withdraw;
            intTotal = prevTotal - withdraw;
            withdrawAmount = withdraw;
            cout << "Account Balance: " << prevTotal << endl
                << "Withdraw Amount: " << withdrawAmount << endl
                << "Current Balance: " << intTotal << endl;
        }
        else if (choice == 'B') {
            cout << "Your current balance is " << intTotal << endl;
        }
        else {
            cout << choice << " is not a valid input!" << endl << endl;
        }

        cout << "Please type in D, W, or B (or E to exit)" << endl
            << "D - Deposit" << endl
            << "W - Withdraw" << endl
            << "B - Balance" << endl;
        std::cin >> choice;
        
    }
    fileOut << total;
    return 0;
}

